# vim:ts=4:et
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

try:
    from .faceset import FaceSet
except ImportError:
    from faceset import FaceSet

class Connectivity:
    def __init__(self, faces):
        self.error = False
        self.edgeFaces = {}
        for f in faces:
            self.add(f)

    def __len__(self):
        return len(self.edgeFaces)

    def __getitem__(self, e):
        if e in self.edgeFaces:
            return self.edgeFaces[e]
        return None

    def add(self, face):
        for i in range(3):
            e = face.edges[i]
            if e in self.edgeFaces:
                print(f"[Connectivity] duplicate edge")
                self.error = True
            else:
                self.edgeFaces[e] = face

    def remove(self, face):
        if type(face) == FaceSet:
            vispoints = set()
            for f in face:
                vispoints |= self.remove(f)
            return vispoints
        else:
            for i in range(3):
                del self.edgeFaces[face.edges[i]]
            return face.vispoints

    def light_faces_int(self, face, point, lit_faces, vert_faces, visited_faces):
        if face in visited_faces or face not in vert_faces:
            return
        visited_faces.add(face)
        if face.can_see(point):
            lit_faces.add(face)
            for i in range(3):
                conface = self[face.redges[i]]
                if not conface:
                    print(f"[Connectivity] incompletely connected face")
                    continue
                self.light_faces_int(conface, point, lit_faces, vert_faces, visited_faces)

    def light_faces(self, first_face, point, vert_faces):
        lit_faces = FaceSet(first_face.mesh)
        visited_faces = set()
        self.light_faces_int(first_face, point, lit_faces, vert_faces[point], visited_faces)
        return lit_faces
